package com.codewiz.tripplanner.exception;

public record ErrorMessage(int code, String message) {
}
