package com.codewiz.tripplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripPlannerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
